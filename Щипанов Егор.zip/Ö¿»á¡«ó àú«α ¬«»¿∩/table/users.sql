USE [BeautyShop]
GO

/****** Object:  Table [dbo].[users]    Script Date: 18.04.2024 15:22:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[users](
	[kod_users] [int] IDENTITY(1,1) NOT NULL,
	[login_FIO] [nvarchar](255) NULL,
	[password] [nvarchar](50) NULL,
	[number] [nvarchar](50) NULL,
	[e_mail] [nvarchar](50) NULL,
 CONSTRAINT [PK_users] PRIMARY KEY CLUSTERED 
(
	[kod_users] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

