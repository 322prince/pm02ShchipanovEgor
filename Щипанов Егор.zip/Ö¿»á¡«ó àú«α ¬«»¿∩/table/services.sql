USE [BeautyShop]
GO

/****** Object:  Table [dbo].[services]    Script Date: 18.04.2024 15:21:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[services](
	[id_services] [int] NOT NULL,
	[kod_sevices] [int] NOT NULL,
	[name] [nvarchar](50) NULL,
	[opisanie] [nvarchar](50) NULL,
	[cost] [money] NULL,
 CONSTRAINT [PK_services] PRIMARY KEY CLUSTERED 
(
	[kod_sevices] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[services]  WITH CHECK ADD  CONSTRAINT [FK_services_services_rashirenoe] FOREIGN KEY([kod_sevices])
REFERENCES [dbo].[services_rashirenoe] ([kod_sr])
GO

ALTER TABLE [dbo].[services] CHECK CONSTRAINT [FK_services_services_rashirenoe]
GO

