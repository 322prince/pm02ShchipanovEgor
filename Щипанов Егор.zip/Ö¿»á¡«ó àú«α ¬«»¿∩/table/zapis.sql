USE [BeautyShop]
GO

/****** Object:  Table [dbo].[zapis]    Script Date: 18.04.2024 15:22:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[zapis](
	[id_zapis] [int] NULL,
	[kod_zapis] [int] IDENTITY(1,1) NOT NULL,
	[kod_users] [int] NULL,
	[kod_staff] [int] NULL,
	[kod_services] [int] NULL,
	[time] [datetime] NULL,
	[comment] [nvarchar](50) NULL,
 CONSTRAINT [PK_zapis] PRIMARY KEY CLUSTERED 
(
	[kod_zapis] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[zapis]  WITH CHECK ADD  CONSTRAINT [FK_zapis_services] FOREIGN KEY([kod_services])
REFERENCES [dbo].[services] ([kod_sevices])
GO

ALTER TABLE [dbo].[zapis] CHECK CONSTRAINT [FK_zapis_services]
GO

ALTER TABLE [dbo].[zapis]  WITH CHECK ADD  CONSTRAINT [FK_zapis_staff] FOREIGN KEY([kod_staff])
REFERENCES [dbo].[staff] ([kod_staff])
GO

ALTER TABLE [dbo].[zapis] CHECK CONSTRAINT [FK_zapis_staff]
GO

ALTER TABLE [dbo].[zapis]  WITH CHECK ADD  CONSTRAINT [FK_zapis_users] FOREIGN KEY([kod_users])
REFERENCES [dbo].[users] ([kod_users])
GO

ALTER TABLE [dbo].[zapis] CHECK CONSTRAINT [FK_zapis_users]
GO

