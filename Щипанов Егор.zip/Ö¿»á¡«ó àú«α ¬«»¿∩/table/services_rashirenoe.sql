USE [BeautyShop]
GO

/****** Object:  Table [dbo].[services_rashirenoe]    Script Date: 18.04.2024 15:22:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[services_rashirenoe](
	[id_sr] [int] NOT NULL,
	[kod_sr] [int] NOT NULL,
	[name] [nvarchar](50) NULL,
	[opisanie] [nvarchar](50) NULL,
 CONSTRAINT [PK_services_rashirenoe] PRIMARY KEY CLUSTERED 
(
	[kod_sr] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

