USE [BeautyShop]
GO

/****** Object:  Table [dbo].[otzivi]    Script Date: 18.04.2024 15:21:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[otzivi](
	[id_otz] [int] NULL,
	[kod_otz] [int] IDENTITY(1,1) NOT NULL,
	[FIO] [nvarchar](50) NULL,
	[Имя мастера] [nvarchar](50) NULL,
	[text] [nvarchar](50) NULL,
	[ocenka] [nvarchar](50) NULL,
 CONSTRAINT [PK_otzivi] PRIMARY KEY CLUSTERED 
(
	[kod_otz] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

