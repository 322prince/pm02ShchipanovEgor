USE [BeautyShop]
GO

/****** Object:  Table [dbo].[staff_raspisanie]    Script Date: 18.04.2024 15:22:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[staff_raspisanie](
	[id_staff_raspisanie] [int] NOT NULL,
	[kod_staff_raspisanie] [int] NOT NULL,
	[data] [nchar](10) NULL,
	[time] [nchar](10) NULL,
 CONSTRAINT [PK_staff_raspisanie] PRIMARY KEY CLUSTERED 
(
	[kod_staff_raspisanie] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

