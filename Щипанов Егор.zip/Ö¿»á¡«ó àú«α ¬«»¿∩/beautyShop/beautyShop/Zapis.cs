﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace beautyShop
{
    public partial class Zapis : Form
    {
        string connectionString = "Data Source=APPK-MAIN;Initial Catalog=BeautyShop;Integrated Security=True";

        public Zapis()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;

            LoadData();
        }

        private void LoadData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("SELECT time, comment FROM Zapis", connection);

                try
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке данных из базы данных: " + ex.Message);
                }
            }
        }

        private void button_addRecord_Click(object sender, EventArgs e)
        {
            string time = textBox1_datapriem.Text;
            string comment = textBox2_pojel.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Zapis (time, comment) VALUES (@Time, @Comment)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Time", time);
                    command.Parameters.AddWithValue("@Comment", comment);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Запись успешно добавлена в базу данных.");
                            textBox1_datapriem.Text = "";
                            textBox2_pojel.Text = "";
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось добавить запись в базу данных.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при добавлении записи в базу данных: " + ex.Message);
                    }
                }
            }
        }

        private void button_cancel_Click(object sender, EventArgs e)
        {
            // Получаем ID выбранной записи
            int selectedRowIndex = dataGridView1.CurrentCell.RowIndex;
            int id = Convert.ToInt32(dataGridView1.Rows[selectedRowIndex].Cells["id_zapis"].Value);

            // Создаем подключение к базе данных
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Создаем запрос SQL DELETE
                string query = "DELETE FROM Zapis WHERE id_zapis = @ID";

                // Создаем команду для выполнения запроса с параметрами
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Добавляем параметр
                    command.Parameters.AddWithValue("@ID", id);

                    try
                    {
                        // Открываем подключение
                        connection.Open();

                        // Выполняем запрос
                        int rowsAffected = command.ExecuteNonQuery();

                        // Проверяем количество удаленных записей
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Запись успешно удалена из базы данных.");
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось удалить запись из базы данных.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении записи из базы данных: " + ex.Message);
                    }
                }
            }
        }

        private void textBox_time_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_comment_TextChanged(object sender, EventArgs e)
        {

        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_add_Click_1(object sender, EventArgs e)
        {
            string time = textBox1_datapriem.Text;
            string comment = textBox2_pojel.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Zapis (time, comment) VALUES (@Time, @Comment)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Time", time);
                    command.Parameters.AddWithValue("@Comment", comment);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Запись успешно добавлена в базу данных.");
                            textBox1_datapriem.Text = "";
                            textBox2_pojel.Text = "";
                            LoadData(); // Перезагрузка данных в DataGridView после добавления записи
                        }
                        else
                        {
                            MessageBox.Show("Не удалось добавить запись в базу данных.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при добавлении записи в базу данных: " + ex.Message);
                    }
                }
            }
        }


        private void button2_cancel_Click_1(object sender, EventArgs e)
        {
            // Проверяем, есть ли выбранная запись
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Получаем ID выбранной записи
                int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["id_zapis"].Value);

                // Создаем подключение к базе данных
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Создаем запрос SQL DELETE
                    string query = "DELETE FROM Zapis WHERE id_zapis = @ID";

                    // Создаем команду для выполнения запроса с параметрами
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Добавляем параметр
                        command.Parameters.AddWithValue("@ID", id);

                        try
                        {
                            // Открываем подключение
                            connection.Open();

                            // Выполняем запрос
                            int rowsAffected = command.ExecuteNonQuery();

                            // Проверяем количество удаленных записей
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Запись успешно удалена из базы данных.");
                                LoadData(); // Перезагрузка данных в DataGridView после удаления записи
                            }
                            else
                            {
                                MessageBox.Show("Не удалось удалить запись из базы данных.");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ошибка при удалении записи из базы данных: " + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.");
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide(); 
            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}
