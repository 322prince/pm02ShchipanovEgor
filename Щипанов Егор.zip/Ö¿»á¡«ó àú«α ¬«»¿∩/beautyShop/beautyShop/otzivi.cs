﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace beautyShop
{
    public partial class otzivi : Form
    {
        string connectionString = "Data Source=APPK-MAIN;Initial Catalog=BeautyShop;Integrated Security=True";

        public otzivi()
        {
            InitializeComponent();
            LoadData();
            StartPosition = FormStartPosition.CenterScreen;

        }

        private void LoadData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("SELECT FIO, [Имя мастера] AS Мастер, [text] AS 'Текст отзыва', ocenka AS 'Оценка' FROM otzivi", connection);

                try
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1_otzivi.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке данных из базы данных: " + ex.Message);
                }
            }
        }

        private void otzivi_Load(object sender, EventArgs e)
        {
            dataGridView1_otzivi.Columns["FIO"].HeaderText = "ФИО";
            dataGridView1_otzivi.Columns["Мастер"].HeaderText = "Мастер";
            dataGridView1_otzivi.Columns["Текст отзыва"].HeaderText = "Текст отзыва";
            dataGridView1_otzivi.Columns["Оценка"].HeaderText = "Оценка";
        }
        private void dataGridView1_otzivi_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_fio_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_text_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_ocenka_TextChanged(object sender, EventArgs e)
        {

        }
        private void button1_add_Click(object sender, EventArgs e)
        {
            // Получаем данные из текстовых полей
            string fio = textBox1_fio.Text;
            string name = textBox2_name.Text;
            string text = textBox3_text.Text;
            string ocenka = textBox4_ocenka.Text;

            // Проверяем, что все поля отзыва заполнены
            if (string.IsNullOrWhiteSpace(fio) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(text) || string.IsNullOrWhiteSpace(ocenka))
            {
                MessageBox.Show("Пожалуйста, заполните все поля отзыва.");
                return; // Прерываем выполнение метода, чтобы предотвратить добавление пустого отзыва
            }

            // Создаем подключение к базе данных
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Создаем запрос SQL INSERT
                string query = "INSERT INTO otzivi (FIO, [Имя мастера], [text], ocenka) VALUES (@FIO, @Name, @Text, @Ocenka)";

                // Создаем команду для выполнения запроса с параметрами
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Добавляем параметры
                    command.Parameters.AddWithValue("@FIO", fio);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Text", text);
                    command.Parameters.AddWithValue("@Ocenka", ocenka);

                    try
                    {
                        // Открываем подключение
                        connection.Open();

                        // Выполняем запрос
                        int rowsAffected = command.ExecuteNonQuery();

                        // Проверяем количество добавленных записей
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Отзыв успешно добавлен в базу данных.");
                            // После успешного добавления, очищаем текстовые поля
                            textBox1_fio.Text = "";
                            textBox2_name.Text = "";
                            textBox3_text.Text = "";
                            textBox4_ocenka.Text = "";
                            // Загружаем данные заново в DataGridView
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось добавить отзыв в базу данных.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при добавлении отзыва в базу данных: " + ex.Message);
                    }

                }
            }
        }

        private void button1_back_Click(object sender, EventArgs e)
        {
            Form1 Form1 = new Form1();

            this.Close();
            Form1.Show();
        }
    }
}


