﻿using System;

namespace beautyShop
{
    partial class Zapis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1_datapriem = new System.Windows.Forms.TextBox();
            this.button1_add = new System.Windows.Forms.Button();
            this.textBox2_pojel = new System.Windows.Forms.TextBox();
            this.button2_cancel = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(306, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(258, 184);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Выберите дату и время приема:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(114, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Пожелания:";
            // 
            // textBox1_datapriem
            // 
            this.textBox1_datapriem.Location = new System.Drawing.Point(188, 5);
            this.textBox1_datapriem.Name = "textBox1_datapriem";
            this.textBox1_datapriem.Size = new System.Drawing.Size(100, 20);
            this.textBox1_datapriem.TabIndex = 3;
            // 
            // button1_add
            // 
            this.button1_add.Location = new System.Drawing.Point(188, 65);
            this.button1_add.Name = "button1_add";
            this.button1_add.Size = new System.Drawing.Size(100, 39);
            this.button1_add.TabIndex = 4;
            this.button1_add.Text = "Записаться";
            this.button1_add.UseVisualStyleBackColor = true;
            this.button1_add.Click += new System.EventHandler(this.button1_add_Click_1);
            // 
            // textBox2_pojel
            // 
            this.textBox2_pojel.Location = new System.Drawing.Point(188, 39);
            this.textBox2_pojel.Name = "textBox2_pojel";
            this.textBox2_pojel.Size = new System.Drawing.Size(100, 20);
            this.textBox2_pojel.TabIndex = 5;
            // 
            // button2_cancel
            // 
            this.button2_cancel.Location = new System.Drawing.Point(188, 110);
            this.button2_cancel.Name = "button2_cancel";
            this.button2_cancel.Size = new System.Drawing.Size(100, 40);
            this.button2_cancel.TabIndex = 6;
            this.button2_cancel.Text = "Отменить запись";
            this.button2_cancel.UseVisualStyleBackColor = true;
            this.button2_cancel.Click += new System.EventHandler(this.button2_cancel_Click_1);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(188, 156);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 40);
            this.button1.TabIndex = 7;
            this.button1.Text = " Вернуться";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Zapis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(576, 208);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2_cancel);
            this.Controls.Add(this.textBox2_pojel);
            this.Controls.Add(this.button1_add);
            this.Controls.Add(this.textBox1_datapriem);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Zapis";
            this.Text = "Zapis";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1_datapriem;
        private System.Windows.Forms.Button button1_add;
        private System.Windows.Forms.TextBox textBox2_pojel;
        private System.Windows.Forms.Button button2_cancel;
        private EventHandler button2_cancel_Click;
        private EventHandler textBox2_pojel_TextChanged;
        private EventHandler button1_add_Click;
        private EventHandler textBox1_datapriem_TextChanged;
        private System.Windows.Forms.Button button1;
    }
}