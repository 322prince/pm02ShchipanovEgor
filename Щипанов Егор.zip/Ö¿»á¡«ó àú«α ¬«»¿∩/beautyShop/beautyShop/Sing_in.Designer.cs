﻿namespace beautyShop
{
    partial class Sing_in
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox4_passwrod = new System.Windows.Forms.TextBox();
            this.textBox2_login = new System.Windows.Forms.TextBox();
            this.button1_enter = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(274, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(229, 39);
            this.label5.TabIndex = 19;
            this.label5.Text = "Авторизация";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(245, 271);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Пароль";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(253, 219);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Почта";
            // 
            // textBox4_passwrod
            // 
            this.textBox4_passwrod.Location = new System.Drawing.Point(327, 264);
            this.textBox4_passwrod.Name = "textBox4_passwrod";
            this.textBox4_passwrod.Size = new System.Drawing.Size(119, 20);
            this.textBox4_passwrod.TabIndex = 14;
            // 
            // textBox2_login
            // 
            this.textBox2_login.Location = new System.Drawing.Point(327, 212);
            this.textBox2_login.Name = "textBox2_login";
            this.textBox2_login.Size = new System.Drawing.Size(119, 20);
            this.textBox2_login.TabIndex = 12;
            // 
            // button1_enter
            // 
            this.button1_enter.Location = new System.Drawing.Point(327, 333);
            this.button1_enter.Name = "button1_enter";
            this.button1_enter.Size = new System.Drawing.Size(119, 39);
            this.button1_enter.TabIndex = 10;
            this.button1_enter.Text = "Войти";
            this.button1_enter.UseVisualStyleBackColor = true;
            this.button1_enter.Click += new System.EventHandler(this.button1_enter_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(343, 375);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(75, 13);
            this.linkLabel1.TabIndex = 20;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Нет аккаунта";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // Sing_in
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox4_passwrod);
            this.Controls.Add(this.textBox2_login);
            this.Controls.Add(this.button1_enter);
            this.Name = "Sing_in";
            this.Text = "Sing_in";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox4_passwrod;
        private System.Windows.Forms.TextBox textBox2_login;
        private System.Windows.Forms.Button button1_enter;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}