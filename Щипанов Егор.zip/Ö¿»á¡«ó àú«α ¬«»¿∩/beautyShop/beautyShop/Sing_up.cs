﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace beautyShop
{
    public partial class Sing_up : Form
    {
        DataBase database = new DataBase();
        public Sing_up()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;

        }

        private void button1_create_Click(object sender, EventArgs e)
        {
            var login_FIO = textBox1.Text;
            var e_mail = textBox2.Text;
            var number = textBox3.Text;
            var password = textBox4.Text;


            if (checkuser())
            {
                MessageBox.Show("Пользователь уже существует!");
                return;
            }
            string querystring = $"insert into users(login_FIO, password, number, e_mail) values ('{login_FIO}', '{password}', '{number}', '{e_mail}')";

            SqlCommand command = new SqlCommand(querystring, database.getConnection());
            command.Parameters.AddWithValue("@login_FIO", login_FIO);
            command.Parameters.AddWithValue("@password", password);
            command.Parameters.AddWithValue("@number", number);
            command.Parameters.AddWithValue("@e_mail", e_mail);

            database.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Аккаунт успешно создан!", "Успех!");
                Sing_in frm_login_FIO = new Sing_in();
                this.Hide();
                frm_login_FIO.ShowDialog();
            }
            else
            {
                MessageBox.Show("Аккаунт не создан!");
            }
            database.closeConnection();
        }

        private Boolean checkuser()
        {
            var login = textBox1.Text;
            var password = textBox4.Text;
            var number = textBox3.Text;
            var e_mail = textBox2.Text;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = $"select login_FIO, password, e_mail, number from users where login_FIO = '{login}' and password = '{password}' and number =  '{number}' and e_mail = '{e_mail}'";

            SqlCommand command = new SqlCommand(querystring, database.getConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                MessageBox.Show("Пользователь уже существует!");
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
