﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;


namespace beautyShop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;

        }

        private void парикмахерскиеУслугиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cut cut = new cut();
            this.Hide();
            cut.Show(); 
        }

        private void услугиВизажистаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            visage visage = new visage();
            this.Hide();
            visage.Show();
        }

        private void ногтевойСервисToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nogti nogti = new nogti();
            this.Hide();
            nogti.Show();
        }

        private void солярийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            solary solary = new solary();
            this.Hide();
            solary.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string phoneNumber = "73433463296";

            // Формируем URI для набора номера
            string uri = "tel:" + phoneNumber;

            // Запускаем стандартное приложение для набора номера
            Process.Start(uri);
        }

        private void process1_Exited(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            otzivi otzivi = new otzivi();
            this.Hide();
            otzivi.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            contact contact = new contact();
            contact.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Zapis zapisForm = new Zapis();

            this.Hide();

            zapisForm.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            masters masters = new masters();
            masters.Show();
            this.Hide(); // Скрыть текущую форму, если это необходимо
        }
    }
}
