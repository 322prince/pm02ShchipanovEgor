﻿namespace beautyShop
{
    partial class otzivi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(otzivi));
            this.dataGridView1_otzivi = new System.Windows.Forms.DataGridView();
            this.button1_add = new System.Windows.Forms.Button();
            this.textBox1_fio = new System.Windows.Forms.TextBox();
            this.textBox2_name = new System.Windows.Forms.TextBox();
            this.textBox3_text = new System.Windows.Forms.TextBox();
            this.textBox4_ocenka = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1_back = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1_otzivi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1_otzivi
            // 
            this.dataGridView1_otzivi.AllowUserToAddRows = false;
            this.dataGridView1_otzivi.AllowUserToDeleteRows = false;
            this.dataGridView1_otzivi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1_otzivi.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1_otzivi.Name = "dataGridView1_otzivi";
            this.dataGridView1_otzivi.ReadOnly = true;
            this.dataGridView1_otzivi.Size = new System.Drawing.Size(474, 281);
            this.dataGridView1_otzivi.TabIndex = 0;
            this.dataGridView1_otzivi.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_otzivi_CellContentClick);
            // 
            // button1_add
            // 
            this.button1_add.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1_add.Location = new System.Drawing.Point(595, 116);
            this.button1_add.Name = "button1_add";
            this.button1_add.Size = new System.Drawing.Size(100, 22);
            this.button1_add.TabIndex = 1;
            this.button1_add.Text = "Добавить отзыв";
            this.button1_add.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1_add.UseVisualStyleBackColor = true;
            this.button1_add.Click += new System.EventHandler(this.button1_add_Click);
            // 
            // textBox1_fio
            // 
            this.textBox1_fio.Location = new System.Drawing.Point(597, 12);
            this.textBox1_fio.Name = "textBox1_fio";
            this.textBox1_fio.Size = new System.Drawing.Size(100, 20);
            this.textBox1_fio.TabIndex = 2;
            this.textBox1_fio.TextChanged += new System.EventHandler(this.textBox1_fio_TextChanged);
            // 
            // textBox2_name
            // 
            this.textBox2_name.Location = new System.Drawing.Point(597, 38);
            this.textBox2_name.Name = "textBox2_name";
            this.textBox2_name.Size = new System.Drawing.Size(100, 20);
            this.textBox2_name.TabIndex = 3;
            this.textBox2_name.TextChanged += new System.EventHandler(this.textBox2_name_TextChanged);
            // 
            // textBox3_text
            // 
            this.textBox3_text.Location = new System.Drawing.Point(597, 64);
            this.textBox3_text.Name = "textBox3_text";
            this.textBox3_text.Size = new System.Drawing.Size(100, 20);
            this.textBox3_text.TabIndex = 4;
            this.textBox3_text.TextChanged += new System.EventHandler(this.textBox3_text_TextChanged);
            // 
            // textBox4_ocenka
            // 
            this.textBox4_ocenka.Location = new System.Drawing.Point(597, 90);
            this.textBox4_ocenka.Name = "textBox4_ocenka";
            this.textBox4_ocenka.Size = new System.Drawing.Size(100, 20);
            this.textBox4_ocenka.TabIndex = 5;
            this.textBox4_ocenka.TextChanged += new System.EventHandler(this.textBox4_ocenka_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(524, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Ваше ФИО:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(513, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Имя мастера:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(511, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Текст отзыва:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(496, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Оценка от 1 до 5:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(567, 179);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(129, 114);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // button1_back
            // 
            this.button1_back.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1_back.Location = new System.Drawing.Point(595, 151);
            this.button1_back.Name = "button1_back";
            this.button1_back.Size = new System.Drawing.Size(100, 22);
            this.button1_back.TabIndex = 11;
            this.button1_back.Text = "Назад";
            this.button1_back.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1_back.UseVisualStyleBackColor = true;
            this.button1_back.Click += new System.EventHandler(this.button1_back_Click);
            // 
            // otzivi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(707, 299);
            this.Controls.Add(this.button1_back);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox4_ocenka);
            this.Controls.Add(this.textBox3_text);
            this.Controls.Add(this.textBox2_name);
            this.Controls.Add(this.textBox1_fio);
            this.Controls.Add(this.button1_add);
            this.Controls.Add(this.dataGridView1_otzivi);
            this.Name = "otzivi";
            this.Text = "otzivi";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1_otzivi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1_otzivi;
        private System.Windows.Forms.Button button1_add;
        private System.Windows.Forms.TextBox textBox1_fio;
        private System.Windows.Forms.TextBox textBox2_name;
        private System.Windows.Forms.TextBox textBox3_text;
        private System.Windows.Forms.TextBox textBox4_ocenka;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1_back;
    }
}