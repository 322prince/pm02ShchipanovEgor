﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace beautyShop
{
    public partial class Sing_in : Form
    {
        DataBase database = new DataBase();

        public Sing_in()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Sing_up frm_sing = new Sing_up();
            frm_sing.ShowDialog();
            this.Hide();
        }

        private void button1_enter_Click(object sender, EventArgs e)
        {
            var login_FIO = textBox2_login.Text;
            var password = textBox4_passwrod.Text;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = "SELECT login_FIO, password FROM users WHERE login_FIO = @login AND password = @password";

            SqlCommand command = new SqlCommand(querystring, database.getConnection());
            command.Parameters.AddWithValue("@login", login_FIO);
            command.Parameters.AddWithValue("@password", password);

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count == 1)
            {
                MessageBox.Show("Вы успешно вошли!", "Успешно!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Form1 frm1 = new Form1();
                this.Hide();
                frm1.ShowDialog();
            }
            else
                MessageBox.Show("Такого аккаунта не существует!", "Аккаунта не существуетт!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }
}
